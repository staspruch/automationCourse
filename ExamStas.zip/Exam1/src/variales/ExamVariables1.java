package variales;

public class ExamVariables1 {

	public static void main(String[] args) {
		long num = 10;
		
		System.out.println("The number is " + num);
	}

}
