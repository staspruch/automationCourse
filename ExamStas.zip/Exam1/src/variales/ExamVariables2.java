package variales;

public class ExamVariables2 {

	public static void main(String[] args) {
		long num1 = 10;
		long num2 = 20;
		
		System.out.println("The sum of two numbers is " + (num1 + num2));

	}

}
