package arrays;

public class ExamArrays4 {

	public static void main(String[] args) {
		int[] numbers = { 3, 5, 7, 9, 11 };

		for (int i = numbers.length - 1; i >= 0; i--) {

			System.out.println(numbers[i]);

		}

	}

}
