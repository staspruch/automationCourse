package arrays;

public class ExamArrays5 {

	public static void main(String[] args) {

		long[] grades = { 30, 50, 70, 90, 60 };
		String[] names = { "David", "Eli", "Yossi", "Gal", "Dafna" };
		long top = grades[0];
		int location = 0;

		for (int i = 0; i < names.length; i++) {

			if (grades[i] > top) {

				top = grades[i];
				location = i;

			}

		}

		System.out.println(names[location] + " has the highest grade");
	}

}
