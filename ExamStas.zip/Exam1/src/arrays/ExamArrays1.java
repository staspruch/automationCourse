package arrays;

public class ExamArrays1 {

	public static void main(String[] args) {

		String[] names = {"David", "Eli", "Yossi", "Gal", "Dafna"};
		
		for (int i = 0; i < names.length; i++) {

			System.out.println(names[i]);

		}

	}
}


