package arrays;

public class ExamArrays2 {

	public static void main(String[] args) {
		
		long num[] = {5,8,9,88,45};
	
		num[0] = 30;
		num[num.length - 1] = 20;
		
		System.out.println("First changed number is " + num[0]);
		System.out.println("Second changed number is " + num[num.length-1]);
	
	
	
	}
}
