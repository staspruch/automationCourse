package arrays;

public class ExamArrays3 {

	public static void main(String[] args) {
		int[] numbers = { 11, 33, 54, 87, 80 };

		for (int i = 0; i < numbers.length; i++) {

			if (numbers[i] == 80) {
				System.out.println("80 is present");

			}
		}
		int sum = 0;

		for (int j = 0; j < numbers.length; j++) {

			sum = sum + numbers[j];

		}

		int average = 0;

		average = sum / numbers.length;
		System.out.println("Sum is " + sum);
		System.out.println("Average is " + average);

	}

}
