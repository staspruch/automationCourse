package conditions;

public class ExamConditions1 {

	public static void main(String[] args) {
		double num = 1.5;
		
		if (num > 5) {
			System.out.println("The numbers is " + num);
		}
		
		else {
			
			System.out.println("The number is lower than 5");
		}
	}

}
