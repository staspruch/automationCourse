package conditions;

public class ExamConditions4 {

	public static void main(String[] args) {

		String name1 = "Stas";
		String name2 = "David";
		long grade1 = 96;
		long grade2 = 97;

		if (grade1 > grade2) {
			
			System.out.println(name1);
			
		} else {
			
			System.out.println(name2);
		}
	}

}
