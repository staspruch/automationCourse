package conditions;

public class ExamConditions3 {

	public static void main(String[] args) {
		long num1 = 8;
		long num2 = 9;
		long num3 = 4;
		long highest = 0;

		if (num1 > num2) {

			highest = num1;

		} else {

			highest = num2;
		}

		if (num3 > highest) {

			highest = num3;

		}
		
		System.out.println("The highest numbers is " + highest);
	}

}


