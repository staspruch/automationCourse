package conditions;

public class ExamConditions2 {

	public static void main(String[] args) {
		String name = "Stas";
		int age = 31;
		
		if (age > 30) {
			System.out.println(name + " " + age);
			
		} else {

			System.out.println("The age is " + age);
		}

	}

}
