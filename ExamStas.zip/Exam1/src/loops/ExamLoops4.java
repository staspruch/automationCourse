package loops;

import java.util.Scanner;

public class ExamLoops4 {

	public static void main(String[] args) {

		Scanner reader = new Scanner(System.in);

		System.out.println("Enter a grade: ");
		
		int grade = reader.nextInt();

		while (grade != -1) {
			
			if (grade < 55) {

				System.out.println("You failed");

			} else {

				if (grade <= 90) {

					System.out.println("You succeeded");

				}

				if (grade > 90) {

					System.out.println("You're excellent");
				}
			}
			
			System.out.println("Enter a grade: ");
			
			grade = reader.nextInt();

		}
		
		System.out.println("Invalid grade");
		reader.close();
	}
}
