package loops;

import java.util.Scanner;

public class ExamLoops3 {

	public static void main(String[] args) {

	
		Scanner reader = new Scanner(System.in);

		System.out.println("Enter a grade: ");

		int grade = reader.nextInt();

		reader.close();

		if (grade < 55) {
			
			System.out.println("You failed");
			
		} else {

			if (grade <= 90) {

				System.out.println("You succeeded");

			}

			if (grade > 90) {
				
				System.out.println("You're excellent");

			}

		}
	}

}
		

